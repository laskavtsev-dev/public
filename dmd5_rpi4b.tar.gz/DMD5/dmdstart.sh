#!/bin/bash

#Define the name of the interface that is listened by API

IF_NAME=eth0
IF_IP=$(ifconfig $IF_NAME | grep 'inet ' | awk '{print $2}')

#Get the IP address of the chosen interface:
#
#while true; do
#    IF_IP=$(ifconfig $IF_NAME | grep 'inet ' | awk '{print $2}')
#    if [[ $IF_IP =~ ^169\.254\..* ]]; then
#	sleep 1
#    else
#	break
#    fi
#done

#Run the API

uvicorn --host $IF_IP board:app

