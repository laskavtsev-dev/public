#!/bin/bash

#Updating and upgrading is always a good idea
sudo apt update
sudo apt -y upgrade

#Creating working directory
sudo mkdir /home/pi/DMD5
sudo cp * /home/pi/DMD5/
sudo chown -R pi:pi /home/pi/DMD5

#Backing up the /boot/config.txt if the backup file doesn't exist
if [ ! -e "/boot/config.txt.bk" ]; then
	sudo cp /boot/config.txt /boot/config.txt.bk
fi

#Updating /boot/config.txt to enable i2c bus
sudo sed -i '/dtparam=i2c_arm=on/s/^#//' /boot/config.txt

#Preparing the dmd5 service
sudo cp ~/DMD5/dmd5.service /etc/systemd/system
sudo systemctl enable dmd5

#Install additional components
sudo pip install uvicorn[standard] fastapi smbus
ln -s ~/DMD5/board.py /usr/local/bin/board.py

echo -e "\e[1;33mYou must reboot your system to complete the setup.\e[0m" 
echo -e "\e[1;33mPress any key to do this immediately...\e[0m"
echo -e "\e[1;33m...or Ctrl+C, to do this later manually\e[0m"
read -n 1
sudo reboot --force
